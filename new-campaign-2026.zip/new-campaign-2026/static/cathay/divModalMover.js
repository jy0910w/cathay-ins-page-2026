$(function () {
    $('#mainform').append($('.modal'));
})

